﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class BeachGame : Minigame
{

    public GameObject sun;
    public GameObject crab;

    public Animator sunAnimator;
    public Animator crabAnimator;

    private Answer sunAnswer;
    private Answer crabAnswer;

    private float timeLimit = 10.0f;
    private float timeLeft;

    private float speed = 0.5f;
    private float sunSpeed;
    private float crabSpeed;

    private void OnEnable()
    {
        if (Input == null)
        {
            Debug.LogError("MinigameInput not set for BeachGame! Starting with default values");
            Input = new MinigameInput(1, 1, 1, null);
        }

        if (Input.BDifficulty > Input.ADifficulty)
        {
            sunAnswer = Answer.A;
            sun.GetComponentInChildren<Text>().text = "A";
            sun.tag = "answerA";

            crabAnswer = Answer.B;
            crab.GetComponentInChildren<Text>().text = "B";
            crab.tag = "answerB";

            sunAnimator.speed = speed + 0.05f * Input.ADifficulty;
            crabAnimator.speed = speed + 0.05f * Input.BDifficulty;
        }
        else
        {
            sunAnswer = Answer.B;
            sun.GetComponentInChildren<Text>().text = "B";
            sun.tag = "AnswerB";

            crabAnswer = Answer.A;
            crab.GetComponentInChildren<Text>().text = "A";
            crab.tag = "AnswerA";

            sunAnimator.speed = speed + 0.05f * Input.BDifficulty;
            crabAnimator.speed = speed + 0.05f * Input.ADifficulty;
        }

        sunAnimator.speed += 0.05f * Input.TimeScale;
        crabAnimator.speed += 0.05f * Input.TimeScale;

        Debug.Log("BeachGame: CrabSpeed=" + crabAnimator.speed + " SunSpeed=" + sunAnimator.speed);
    }

    public override void BeginGame()
    {
        this.enabled = true;
        sunAnimator.enabled = true;
        crabAnimator.enabled = true;

    }

    public void AnswerClicked()
    {
        GameObject clicked = EventSystem.current.currentSelectedGameObject;

        sun.GetComponent<Button>().interactable = false;
        crab.GetComponent<Button>().interactable = false;

        if (clicked == sun)
        {
            sunAnimator.enabled = false;
            Finish(sunAnswer);
        }
        else if(clicked == crab)
        {
            crabAnimator.enabled = false;
            Finish(crabAnswer);
        }
    }
}
