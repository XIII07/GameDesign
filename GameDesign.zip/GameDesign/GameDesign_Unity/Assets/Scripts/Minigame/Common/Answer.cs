﻿public enum Answer
{
    A,
    B,
    None
}